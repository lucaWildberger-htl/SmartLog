## Installation (Windows)

1. Extract the ZIP file to `C:\win`.
2. Modify system environment variables:
   - Go to **System Properties** >> **Advanced** >> **Environment Variables**.
   - Under **User Variables** for `<User>`, find and select **Path**, then click **Edit**.
   - Click **New**, then add: `C:\win\SmartLog`.
   - Confirm with **OK** on all windows.
3. Open **Command Prompt** and type `SmartLog -help` to get usage instructions.
